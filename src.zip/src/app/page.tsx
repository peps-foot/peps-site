'use client';

// Déclarations de types pour HomePage
interface Grid {
  id: string
  title: string
  description: string
}

interface Match {
  id: string
  date: string
  home_team: string
  away_team: string
  odd_1: number
  odd_X: number
  odd_2: number
  pick?: string
  score_home?: number
  score_away?: number
  points?: number
}

interface BonusDef {
  id: string
  code: string
  description: string
  parameters?: any
}

import { NavBar } from '@/components/NavBar';
import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { supabase } from '@/lib/supabaseClient';
import { useRouter, useSearchParams, usePathname } from 'next/navigation';

const bonusLogos: Record<string,string> = {
  KANTE: '/images/kante.png',
  RIBERY: '/images/ribery.png',
  ZLATAN: '/images/zlatan.png',
};

export default function HomePage() {
  const hasRun = useRef(false);
  const [grids, setGrids]    = useState<Grid[]>([]);
  const [grid, setGrid]             = useState<Grid|null>(null);
  const [matches, setMatches]       = useState<Match[]>([]);
  const [bonusDefs, setBonusDefs]   = useState<BonusDef[]>([]);
  const [gridBonuses, setGridBonuses] = useState< { bonus_definition: string; match_id: number; parameters: any }[] >([]);
  const [loading, setLoading]       = useState(true);
  const [error, setError]           = useState<string|null>(null);
  const [openedBonus, setOpenedBonus] = useState<BonusDef|null>(null);
  const [popupMatch1, setPopupMatch1] = useState<string>(''); 
  const [popupMatch0, setPopupMatch0] = useState<string>(''); 
  const [popupPair, setPopupPair]     = useState<'1–N'|'N–2'|'1–2'>('1–N');
  const [popupPick, setPopupPick]     = useState<'1'|'N'|'2'>('1');
  const router        = useRouter();
  const pathname     = usePathname();
  const searchParams  = useSearchParams();
  const initialPage   = Number(searchParams.get('page')) || 0;
  // 2) État de l’index de grille
  const [currentIdx, setCurrentIdx] = useState(initialPage);
  // 3) Change l’index ET met à jour l’URL en shallow routing
  const goToPage = (i: number) => {    setCurrentIdx(i);
    // Reconstruit les params en conservant les autres éventuels
    const params = new URLSearchParams(Array.from(searchParams.entries()));
    params.set('page', String(i));
    router.replace(`${pathname}?${params.toString()}`, undefined, { shallow: true });  };
  // 4) Fonctions de navigation
  const prevGrid = () => {    if (currentIdx > 0) goToPage(currentIdx - 1);  };
  const nextGrid = () => {    if (currentIdx < grids.length - 1) goToPage(currentIdx + 1);  };
  const currentGrid = grids[currentIdx] || { title: '', description: '' };
  const [loadingGrids, setLoadingGrids] = useState<boolean>(true);
  const [loadingGrid,  setLoadingGrid]  = useState<boolean>(false);
  const [scores, setScores] = useState< { grid_match_id: string; pick: string; points: number }[]>([]);
  const [totalPoints, setTotalPoints] = useState<number>(0);

  // format FR pour la date
  const fmtDate = (d: string) =>
    new Date(d).toLocaleString('fr-FR',{
      day:'2-digit', month:'2-digit',
      hour:'2-digit', minute:'2-digit'
    }).replace(/\u202F/g,' ');

  // 🏗️ Duplique les grilles de l’admin pour un nouveau joueur
  async function initializePlayerGrids(userId: string) {
    console.log("🚀 Initialisation pour :", userId);
    // 🛑 Sécurité : ne duplique pas si des grilles existent déjà
    const { data: existingGrids, error: existingError } = await supabase
      .from('grids')
      .select('id')
      .eq('user_id', userId)
      .limit(1);

    if (existingGrids && existingGrids.length > 0) {
      console.warn("🛑 Grilles déjà existantes pour cet utilisateur, annulation duplication.");
      return;
    }

    // 1. Récupérer les grilles de référence de l’admin
    const { data: refGrids, error: gridError } = await supabase
      .from('grids')
      .select('*')
      .eq('user_id', 'ded40192-4ecc-49c4-a990-118262d14be6'); // ID ADMIN

    if (gridError || !refGrids) {
      console.error("❌ Erreur récupération grilles :", gridError);
      return;
    }

    console.log("📋 Grilles trouvées pour duplication :", refGrids.map(g => g.title));

    for (const refGrid of refGrids) {
      console.log("🔄 Traitement de la grille :", refGrid.id, refGrid.title);

      // 2. Créer une nouvelle grille pour le joueur
      const { data: newGrid, error: insertGridError } = await supabase
        .from('grids')
        .insert({
          user_id: userId,
          title: refGrid.title,
          description: refGrid.description,
          allowed_bonuses: refGrid.allowed_bonuses
        })
        .select()
        .single();

      if (insertGridError || !newGrid) {
        console.error("❌ Erreur création grille joueur :", insertGridError);
        continue;
      }

      console.log("📦 Nouvelle grille créée :", newGrid.id);

      // 3. Récupérer les grid_items de la grille admin
      const { data: items, error: itemError } = await supabase
        .from('grid_items')
        .select('match_id')
        .eq('grid_id', refGrid.id);

      console.log("🧩 ID utilisé pour grid_items :", refGrid.id);
      console.log("📦 grid_items trouvés :", items?.length);

      if (itemError || !items || items.length === 0) {
        console.warn("⚠️ Aucun item à copier pour", refGrid.title);
        continue;
      }

      // 4. Copier les grid_items vers la nouvelle grille
      const newItems = items.map(item => ({
        grid_id: newGrid.id,
        match_id: item.match_id
      }));

      const { error: insertItemsError } = await supabase
        .from('grid_items')
        .insert(newItems);

      if (insertItemsError) {
        console.error("❌ Erreur duplication grid_items :", insertItemsError);
        continue;
      }

      console.log("📤 grid_items copiés :", newItems);

      // 5. Créer les grid_matches pour le joueur
      const newMatches = items.map(item => ({
        user_id: userId,
        grid_id: newGrid.id,
        match_id: item.match_id,
        pick: null
      }));

      const { error: insertMatchesError } = await supabase
        .from('grid_matches')
        .insert(newMatches);

      if (insertMatchesError) {
        console.error("❌ Erreur insertion grid_matches :", insertMatchesError);
        continue;
      }

      console.log("🧾 grid_matches créés :", newMatches);
      console.log("✅ Grille dupliquée pour", userId, ":", newGrid.title);
    }
  }

  useEffect(() => {
    console.log("🚨 useEffect déclenché");
    if (hasRun.current) return;
    hasRun.current = true;

    const initAndLoad = async () => {
      setLoadingGrids(true);

      const { data: { user }, error } = await supabase.auth.getUser();
      if (error || !user) {
        setError("Utilisateur non connecté.");
        setLoadingGrids(false);
        return;
      }

      // Vérifie si l'utilisateur a déjà des grilles
      const { data: existing, error: checkError } = await supabase
        .from('grid_matches')
        .select('id')
        .eq('user_id', user.id)
        .limit(1);

      if (checkError) {
        setError("Erreur lors de la vérification des grilles.");
        setLoadingGrids(false);
        return;
      }

      if (!existing || existing.length === 0) {
        console.log("❌ Aucune grille, initialisation...");
        // Double sécurité avec Supabase
        const { data: doubleCheck } = await supabase
          .from("grid_matches")
          .select("id")
          .eq("user_id", user.id)
          .limit(1);

        if (!doubleCheck || doubleCheck.length === 0) {
          await initializePlayerGrids(user.id);
        } else {
          console.log("🛑 Grilles déjà créées, annulation duplication.");
        }
      }

      await loadUserGrids(user.id);
    };

    initAndLoad();
  }, []);

  async function loadUserGrids(userId: string) {
  const { data: matchData, error: matchError } = await supabase
    .from("grid_matches")
    .select(`
      grid_id,
      match_id,
      pick,
      matches (
        date,
        home_team,
        away_team,
        base_1_points,
        base_n_points,
        base_2_points
      ),
      grids (
        id,
        title,
        description
      )
    `)
    .eq("user_id", userId);

  if (matchError) {
    setError("Erreur chargement grilles.");
    setLoadingGrids(false);
    return;
  }

  const groupedByGrid: Record<string, { grid: Grid; matches: Match[] }> = {};
  for (const m of matchData) {
    const gridId = m.grid_id;
    if (!groupedByGrid[gridId]) {
      groupedByGrid[gridId] = {
        grid: {
          id: gridId,
          title: m.grids.title,
          description: m.grids.description,
        },
        matches: [],
      };
    }
    groupedByGrid[gridId].matches.push({
      id: m.match_id,
      date: m.matches.date,
      home_team: m.matches.home_team,
      away_team: m.matches.away_team,
      odd_1: m.matches.base_1_points,
      odd_X: m.matches.base_n_points,
      odd_2: m.matches.base_2_points,
      pick: m.pick,
    });
  }

  const gridsList = Object.values(groupedByGrid).map((g) => g.grid);
  const currentGridMatches = Object.values(groupedByGrid)[0]?.matches || [];

  setGrids(gridsList);
  setGrid(gridsList[0]);
  setMatches(currentGridMatches);
  setLoadingGrids(false);
  }

  // 📥 Chargement complet des données pour la grille sélectionnée
  useEffect(() => {
    if (grids.length === 0) return;
    const gridId = grids[currentIdx].id;
    if (!gridId) return;

    (async () => {
      try {
        setLoadingGrid(true);

        // 1) Fetch de la grille active
        const { data: g, error: ge } = await supabase
          .from<Grid>('grids')
          .select(`id, title, grid_items(match_id), allowed_bonuses`)
          .eq('id', gridId)
          .single();
        if (ge) throw ge;
        setGrid(g);
        console.log("📦 grille active chargée :", g);

        // 2) Préparer la liste des match_id à récupérer
        const ids = (g.grid_items || []).map(x => x.match_id);
        console.log('🔍 match IDs to fetch =', ids);

        // 3) Fetch des matchs (côtes et scores)
        const { data: raws, error: re } = await supabase
          .from<RawMatch>('matches')
          .select(`
            id,
            date,
            home_team,
            away_team,
            score_home,
            score_away,
            odd_1_snapshot,
            odd_n_snapshot,
            odd_2_snapshot,
            base_1_points,
            base_n_points,
            base_2_points
          `)
          .in('id', ids)
          .order('date', { ascending: true });
        if (re) throw re;
        console.log('🔍 raws fetched =', raws);

        // 4) Fetch des picks posés dans grid_matches
        const { data: rawGridMatches, error: gmError } = await supabase
          .from('grid_matches')
          .select('id, match_id, pick')
          .eq('grid_id', gridId);
        if (gmError) throw gmError;
        const pickMap = new Map<string,string>(
          (rawGridMatches || []).map(gm => [gm.match_id, gm.pick])
        );
        console.log('🔍 rawGridMatches =', rawGridMatches);

        // 5) Appel RPC pour récupérer les points
        const { data: scoreRows, error: scoreError } = await supabase
          .rpc('compute_scores', { p_grid_id: gridId });
        if (scoreError) throw scoreError;
        const scoreMap = new Map<string,number>(
          (scoreRows as any[]).map(r => [r.grid_match_id, r.points])
        );
        console.log('🔍 scoreRows =', scoreRows);

        // 6) Fusionner tout pour construire le tableau final
        const clean = (raws || []).map(m => {
          // trouver l'enregistrement grid_match pour ce match
          const gm = rawGridMatches?.find(gm => gm.match_id === m.id);
          return {
            id:         m.id,
            date:       m.date,
            home_team:  m.home_team,
            away_team:  m.away_team,
            score_home: m.score_home,
            score_away: m.score_away,
            odd_1:      m.odd_1_snapshot,
            odd_X:      m.odd_n_snapshot,
            odd_2:      m.odd_2_snapshot,
            base_1_points: m.base_1_points,
            base_n_points: m.base_n_points,
            base_2_points: m.base_2_points,
            pick:       gm?.pick ?? null,
            points:     gm ? scoreMap.get(gm.id) ?? 0 : null,
          };
        });
        setMatches(clean);
        const totalPoints = clean.reduce((acc, m) => acc + (m.points || 0), 0);
        setTotalPoints(totalPoints);

        // 7) Fetch des bonus déjà joués pour cette grille
        const { data: gbs, error: gbe } = await supabase
          .from('grid_bonus')
          .select('bonus_definition, match_id, parameters')
          .eq('grid_id', gridId);
        if (gbe) throw gbe;
        console.log('🔍 gridBonuses =', gbs);
        setGridBonuses(gbs || []);

        // 8) Fetch des définitions de bonus
        const { data: bd, error: be } = await supabase
          .from<BonusDef>('bonus_definition')
          .select('id, code, description');
        if (be) throw be;
        setBonusDefs(bd || []);

      } catch (e: any) {
        console.error(e);
        setError(e.message || String(e));
      } finally {
        setLoadingGrid(false);
      }
    })();
  }, [currentIdx, grids]);

  // 🧮 Calcul de points par match avec RPC compute_scores()
  useEffect(() => {
  if (!grid?.id) return;

  async function loadScores() {
    const { data, error } = await supabase
      .rpc('compute_scores', { p_grid_id: grid.id });
    if (error) console.error('compute_scores error', error);
    else setScores(data as any);
  }

  loadScores();
  }, [grid?.id]);

if (loadingGrids) {
  return (
    <main className="flex items-center justify-center min-h-screen">
      <span className="text-lg">🔄 Chargement des grilles…</span>
    </main>
  );
}

if (error) {
  return (
    <div className="p-6 text-red-600">
      ⚠ {error}
    </div>
  );
}

if (!grid) {
  return (
    <div className="p-6 text-orange-500">
      Aucune grille trouvée pour ce joueur.
    </div>
  );
}

  // Upsert pronostic 1/N/2
  const handlePick = async (
    match_id: string,
    pick: '1' | 'N' | '2'
  ) => {
    // 🔐 Récupération de l'utilisateur connecté
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    if (userError || !user) {
      console.error("Utilisateur non connecté pour le pick !");
      return;
    }

    // 🎯 Retrouver le match dans les données locales
    const m = matches.find(x => x.id === match_id);
    if (!m) return;

    // ⛔ Ne rien faire si le match a déjà commencé
    if (new Date(m.date) <= new Date()) return;

    // 📝 Enregistrement du pick en base
    const { error: pe } = await supabase
      .from('grid_matches')
      .upsert(
        {
          user_id: user.id,
          grid_id: grid.id,
          match_id,
          pick
        },
        { onConflict: ['user_id', 'grid_id', 'match_id'] }
      );

    if (pe) {
      console.error('Erreur upsert pick:', pe);
      return;
    }

    // 🧠 Mise à jour en local du state
    setMatches(ms =>
      ms.map(x =>
        x.id === match_id
          ? { ...x, pick }
          : x
      )
    );

    // 📊 Recalcul des scores
    const { data: newScores, error: re } = await supabase
      .rpc('compute_scores', { p_grid_id: grid.id });
    if (re) {
      console.error('Erreur compute_scores après pick:', re);
      return;
    }

    const scoreMap = new Map<string, number>(
      (newScores as any[]).map(r => [r.grid_match_id, r.points])
    );

    setMatches(ms =>
      ms.map(x => ({
        ...x,
        points: scoreMap.get(x.id) ?? 0
      }))
    );
  };

  // Validation / modification
  const handleBonusValidate = async () => {
    if (!openedBonus) return;
  
    try {
      // 1) On voit arriver le bonus
      console.log('🔥 handleBonusValidate start', {
        bonusCode:   openedBonus.code,
        popupMatch1, popupMatch0, popupPair, popupPick
      });
  
      // 2) Payload de base
      const payload: any = {
        grid_id:          grid!.id,         // UUID de la grille
        bonus_definition: openedBonus.id,   // UUID du bonus
        match_id:         popupMatch1,      // pour KANTÉ/ZLATAN, c'est le match ; pour RIBÉRY, on prend match_win
        parameters:       {}                // 
      };
  
      // 3) Complète selon le code du bonus
      switch (openedBonus.code) {
        case 'KANTE':
          if (!popupMatch1) {
            console.warn('KANTE sans match'); 
            return;
          }
          payload.parameters = {
            picks:
              popupPair === '1–N' ? ['1','N']
            : popupPair === 'N–2' ? ['N','2']
            : ['1','2']
          };
          break;
  
        case 'RIBERY':
          if (!popupMatch1 || !popupMatch0) {
            alert('Choisissez les deux matchs');
            return;
          }
          if (popupMatch1 === popupMatch0) {
            alert('Même match deux fois');
            return;
          }
          payload.match_id = popupMatch1;      // on stocke le match à 3 croix
          payload.parameters = {
            match_win:  popupMatch1,
            match_zero: popupMatch0
          };
          break;
  
        case 'ZLATAN':
          if (!popupMatch1) {
            console.warn('ZLATAN sans match');
            return;
          }
          // payload.match_id est déjà popupMatch1
          payload.parameters = {
            pick: popupPick
          };
          break;
  
        default:
          console.error('Bonus non géré :', openedBonus.code);
          return;
      }
  
      // 4) Vérif dans la console
      console.log('→ payload avant upsert:', payload);
  
      // 5) Envoi à Supabase
      const { data, error: be } = await supabase
        .from('grid_bonus')
        .upsert(payload, {
          onConflict: ['grid_id','bonus_definition']
        });
  
      if (be) {
        console.error('❌ Supabase upsert error', be);
        alert('Erreur Supabase : ' + be.message);
        return;
      }
      console.log('✅ Supabase upsert OK', data);
  
      // 6) Mise à jour locale + fermeture popup
      setGridBonuses(gbs => [
        ...gbs.filter(x => x.bonus_definition !== openedBonus.id),
        {
          bonus_definition: openedBonus.id,
          match_id:         payload.match_id,  // pour KANTE/ZLATAN : le match, pour Ribéry : match_win
          parameters:       payload.parameters
        }
      ]);
      setOpenedBonus(null);
      setPopupMatch1('');
      setPopupMatch0('');
    }
    catch (e: any) {
      console.error('🔥 handleBonusValidate catch', e);
      alert('Erreur enregistrement bonus : ' + (e.message || e));
    }
  };      

  // Suppression d’un bonus
  const handleBonusDelete = async () => {
    if (!openedBonus) return;
    try {
      // 1) Suppression en base
      const { error: de } = await supabase
        .from('grid_bonus')
        .delete()
        .eq('grid_id', grid.id)
        .eq('bonus_definition', openedBonus.id);
      if (de) throw de;

      // 2) Mise à jour locale de gridBonuses
      setGridBonuses(gbs =>
        gbs.filter(x => x.bonus_definition !== openedBonus.id)
      );

      // 3) Recalcul des points via RPC
      const { data: newScores, error: re } = await supabase
        .rpc('compute_scores', { p_grid_id: grid.id });
      if (re) {
        console.error('Erreur compute_scores après delete bonus:', re);
      } else {
        const scoreMap = new Map<string, number>(
          (newScores as any[]).map(r => [r.grid_match_id, r.points])
        );
        // 4) Mise à jour de matches avec les nouveaux points
        setMatches(ms =>
          ms.map(x => ({
            ...x,
            points: scoreMap.get(x.id) ?? 0
          }))
        );
      }

      // 5) Reset du popup
      setOpenedBonus(null);
      setPopupMatch1('');
      setPopupMatch0('');
    }
    catch (e: any) {
      console.error('🔥 handleBonusDelete catch', e);
      alert('Erreur suppression bonus : ' + (e.message || e));
    }
  };

  // helpers bonus
  const isPlayed = gridBonuses.length>0;
  const playedBonusCode = bonusDefs.find(b=>b.id===gridBonuses[0]?.bonus_definition)?.code;

return (
    <>
    <NavBar />
  <main className="container mx-auto px-4 py-8">
    {/* 1) ZONE D’INFORMATION PLEIN LARGEUR */}
{/* ── ZONE INFO ── */}
<section className="w-full mb-8">
  <div className="bg-white rounded-lg p-6 shadow flex flex-col md:flex-row items-center">
    
    {/* 1) NAVIGATION GRILLES (← title →) */}
    <div className="w-full md:w-1/3 flex items-center justify-center space-x-4 mb-4 md:mb-0">
    {/* ← Précédent */}
    <button
      onClick={prevGrid}
      disabled={currentIdx === 0}
      className="bg-[#212121] hover:bg-gray-800 text-white rounded-full p-2 disabled:opacity-30 disabled:cursor-not-allowed"
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-6 w-6"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        strokeWidth={2}
      >
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
      </svg>
    </button>

      {/* Nom de la grille courante */}
      <span className="text-2xl font-semibold">
        {currentGrid?.title /* <-- Assure-toi que c’est bien currentGrid, pas grid */}
      </span>

      {/* → Suivant */}
      <button
        onClick={nextGrid}
        disabled={currentIdx === grids.length - 1}
        className="bg-[#212121] hover:bg-gray-800 text-white rounded-full p-2 disabled:opacity-30 disabled:cursor-not-allowed"
      >
        <svg
          xmlns="http://www.w3.org/2000/svg"
          className="h-6 w-6"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
          strokeWidth={2}
        >
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
        </svg>
      </button>
    </div>

    {/* 2) POINTS (inchangé) */}
    <div className="w-full md:w-1/3 text-center mb-4 md:mb-0">
      <span className="text-lg font-semibold">POINTS :</span>
      <span className="ml-2 text-gray-600">{totalPoints}</span>
    </div>

    {/* 3) DESCRIPTION DE LA GRILLE (inchangé pour l’instant) */}
    <div className="w-full md:w-1/3 text-right">
      <p className="text-gray-700">
        {currentGrid?.description /* <-- idem, currentGrid */}
      </p>
    </div>
  </div>
</section>

    {/* 2) CONTENU PRINCIPAL : GRILLE (2/3) & BONUS (1/3) */}
    <div className="p-6 flex flex-col lg:flex-row gap-6">
      {/* ── GRILLE ── */}
      <div className="w-full lg:w-2/3">
        <div className="border rounded-lg space-y-2">
          <h1 className="text-3xl font-bold text-center p-2">{currentGrid?.title}</h1>
          <div className="space-y-1">
            {loadingGrid ? (
              <div className="p-6 text-center">🔄 Chargement de la grille…</div>
            ) : (
              matches.map((m) => {
                const now = new Date()
                const dt = new Date(m.date)
                const upcoming = dt > now

                // 1) Bonus actif
                const bonusEntry = gridBonuses[0]
                const bonusDef = bonusDefs.find(
                  (d) => d.id === bonusEntry?.bonus_definition
                )
                const bonusCode = bonusDef?.code
                const params = bonusEntry?.parameters || {}
                const matchWin  = params.match_win as string
                const matchZero = params.match_zero as string

                // 2) Prépare picks et disabled
                let picksForThisMatch: string[] = []
                let isDisabled = !upcoming

                if (bonusEntry && bonusCode) {
                  switch (bonusCode) {
                    case 'RIBERY': {
                      if (m.id === matchWin) {
                        picksForThisMatch = ['1','N','2'];
                        isDisabled = true
                      } else if (m.id === matchZero) {
                        picksForThisMatch = []
                        isDisabled = true
                      } else {
                        picksForThisMatch = m.pick ? [m.pick] : []
                      }
                      break
                    }
                    case 'KANTE': {
                      const matchK = bonusEntry.match_id
                      if (m.id === matchK) {
                        picksForThisMatch = params.picks || []
                        isDisabled = true
                      } else {
                        picksForThisMatch = m.pick ? [m.pick] : []
                      }
                      break
                    }
                    case 'ZLATAN': {
                      const matchZ = bonusEntry.match_id
                      if (m.id === matchZ) {
                        picksForThisMatch = params.pick ? [params.pick] : []
                        isDisabled = true
                      } else {
                        picksForThisMatch = m.pick ? [m.pick] : []
                      }
                      break
                    }
                    default:
                      picksForThisMatch = m.pick ? [m.pick] : []
                  }
                } else {
                  picksForThisMatch = m.pick ? [m.pick] : []
                }

                return (
                  <div
                    key={m.id}
                    className="border rounded-lg grid grid-cols-7 grid-rows-2 items-center p-1"
                  >
                    {/* LIGNE 1 */}
                    <div className="text-center text-sm">{fmtDate(m.date)}</div>
                    <div className="text-center font-medium">{m.home_team}</div>
                    {(['1', 'N', '2'] as const).map((opt) => {
                      const isX = picksForThisMatch.includes(opt)
                      return (
                        <div
                          key={opt}
                          onClick={() =>
                            !isDisabled &&
                            handlePick(
                              m.id,
                              opt,
                              opt === '1'
                                ? m.odd_1
                                : opt === 'N'
                                ? m.odd_X
                                : m.odd_2
                            )
                          }
                          className={`w-8 h-8 mx-auto border rounded flex items-center justify-center text-sm ${
                            isDisabled ? 'opacity-50' : 'cursor-pointer'
                          }`}
                        >
                          {isX ? 'X' : opt}
                        </div>
                      )
                    })}
                    <div className="text-center font-medium">{m.away_team}</div>
                    <div className="flex justify-center">
                      {bonusEntry ? (
                        bonusCode === 'RIBERY' ? (
                          (m.id === matchWin || m.id === matchZero) ? (
                            <Image
                              src={bonusLogos['RIBERY']}
                              alt="RIBERY bonus"
                              width={32}
                              height={32}
                              className="rounded-full"
                            />
                          ) : (
                            <div className="w-6 h-6 bg-blue-500 rounded-full" />
                          )
                        ) : m.id === bonusEntry.match_id ? (
                          <Image
                            src={bonusLogos[bonusCode!]}
                            alt={`${bonusCode} bonus`}
                            width={32}
                            height={32}
                            className="rounded-full"
                          />
                        ) : (
                          <div className="w-6 h-6 bg-blue-500 rounded-full" />
                        )
                      ) : (
                        <div className="w-6 h-6 bg-blue-500 rounded-full" />
                      )}
                    </div>

                    {/* LIGNE 2 */}
                    <div className="text-center text-xs text-gray-600">
                      {m.score_home != null ? 'Terminé' : 'À venir'}
                    </div>
                    <div className="text-center font-semibold">
                      {m.score_home != null ? m.score_home : '–'}
                    </div>
                    <div className="text-center text-xs">
                      {m.base_1_points ?? '-'}
                    </div>
                    <div className="text-center text-xs">
                      {m.base_n_points ?? '-'}
                    </div>
                    <div className="text-center text-xs">
                      {m.base_2_points ?? '-'}
                    </div>
                    <div className="text-center font-semibold">
                      {m.score_away != null ? m.score_away : '–'}
                    </div>
                    <div className="text-center text-sm">
                      {m.score_home != null ? `${m.points || 0} pts` : '–'}
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </div>
      </div>

      {/* ── BONUS ── */}
      <div className="w-full lg:w-1/3">
        <div className="border rounded-lg p-4 space-y-4">
          {/* En-tête */}
          <div className="font-medium">
            {gridBonuses.length > 0
              ? `Tu as déjà joué 1 bonus :`
              : `Joue 1 des ${bonusDefs.length} bonus :`}
          </div>

          {/* Liste des defs */}
          {bonusDefs.map(b => {
            const isPlayed = gridBonuses.some(
              gb => gb.bonus_definition === b.id
            )
            const hasPlayedAny = gridBonuses.length > 0

            return (
              <div
                key={b.id}
                className="border rounded-lg p-3 bg-blue-50 flex items-center justify-between"
              >
                {/* Icône + libellé */}
                <div className="flex items-center">
                  <Image
                    src={bonusLogos[b.code]}
                    alt={b.code}
                    width={40}
                    height={40}
                    className="rounded-full"
                  />
                  <div className="ml-3">
                    <div className="text-lg font-bold text-green-600">
                      {b.code}
                    </div>
                    <div className="text-sm">{b.description}</div>
                  </div>
                </div>

                {/* Bouton : si aucun bonus joué → JOUER ; si c'est celui-ci joué → MODIFIER */}
                <div>
                  {!hasPlayedAny && (
                    <button
                      onClick={() => setOpenedBonus(b)}
                      className="px-3 py-1 border rounded hover:bg-gray-100"
                    >
                      JOUER
                    </button>
                  )}
                  {isPlayed && (
                    <button
                      onClick={() => setOpenedBonus(b)}
                      className="px-3 py-1 border rounded hover:bg-gray-100"
                    >
                      MODIFIER
                    </button>
                  )}
                </div>
              </div>
            )
          })}
        </div>
      </div>


      {/* ── POPUP BONUS ── */}
      {openedBonus && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 w-80 relative">
            <button
              onClick={() => setOpenedBonus(null)}
              className="absolute top-2 right-2 text-black text-xl"
            >
              ✕
            </button>
            <h2 className="text-2xl font-bold mb-2">
              {openedBonus.code}
            </h2>
            <p className="mb-4">
              {openedBonus.description}
            </p>

            {/* Contenu selon bonus */}
            {openedBonus.code === 'RIBERY' ? (
              <>
                <label className="block mb-3">
                  Match à 3 croix
                  <select
                    value={popupMatch1}
                    onChange={(e) =>
                      setPopupMatch1(e.target.value)
                    }
                    className="mt-1 block w-full border rounded p-2"
                  >
                    <option value="">
                      — Choisir match —
                    </option>
                    {matches.map((m) => (
                      <option
                        key={m.id}
                        value={String(m.id)}
                      >
                        {m.home_team} vs {m.away_team}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block mb-6">
                  Match à 0 croix
                  <select
                    value={popupMatch0}
                    onChange={(e) =>
                      setPopupMatch0(e.target.value)
                    }
                    className="mt-1 block w-full border rounded p-2"
                  >
                    <option value="">
                      — Choisir match —
                    </option>
                    {matches.map((m) => (
                      <option
                        key={m.id}
                        value={String(m.id)}
                      >
                        {m.home_team} vs {m.away_team}
                      </option>
                    ))}
                  </select>
                </label>
              </>
            ) : openedBonus.code === 'ZLATAN' ? (
              <>
                <label className="block mb-3">
                  Match
                  <select
                    value={popupMatch1}
                    onChange={(e) =>
                      setPopupMatch1(e.target.value)
                    }
                    className="mt-1 block w-full border rounded p-2"
                  >
                    <option value="">
                      — Choisir match —
                    </option>
                    {matches.map((m) => (
                      <option
                        key={m.id}
                        value={String(m.id)}
                      >
                        {m.home_team} vs {m.away_team}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block mb-6">
                  Pronostic
                  <select
                    value={popupPick}
                    onChange={(e) =>
                      setPopupPick(e.target.value as any)
                    }
                    className="mt-1 block w-full border rounded p-2"
                  >
                    <option value="1">1</option>
                    <option value="N">N</option>
                    <option value="2">2</option>
                  </select>
                </label>
              </>
            ) : (
              <>
                <label className="block mb-3">
                  Match
                  <select
                    value={popupMatch1}
                    onChange={(e) =>
                      setPopupMatch1(e.target.value)
                    }
                    className="mt-1 block w-full border rounded p-2"
                  >
                    <option value="">
                      — Choisir match —
                    </option>
                    {matches.map((m) => (
                      <option
                        key={m.id}
                        value={String(m.id)}
                      >
                        {m.home_team} vs {m.away_team}
                      </option>
                    ))}
                  </select>
                </label>
                <label className="block mb-6">
                  Paire de croix
                  <select
                    value={popupPair}
                    onChange={(e) =>
                      setPopupPair(e.target.value as any)
                    }
                    className="mt-1 block w-full border rounded p-2"
                  >
                    <option value="1–N">1 – N</option>
                    <option value="N–2">N – 2</option>
                    <option value="1–2">1 – 2</option>
                  </select>
                </label>
              </>
            )}
            <div className="flex justify-between">
              {gridBonuses.some(
                (b) => b.bonus_definition === openedBonus.id
              ) && (
                <button
                  onClick={handleBonusDelete}
                  className="px-4 py-2 bg-red-500 text-white rounded"
                >
                  Supprimer
                </button>
              )}
              <button
                onClick={handleBonusValidate}
                className="px-4 py-2 bg-green-500 text-white rounded"
              >
                Valider
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  </main>
  </>
)
}